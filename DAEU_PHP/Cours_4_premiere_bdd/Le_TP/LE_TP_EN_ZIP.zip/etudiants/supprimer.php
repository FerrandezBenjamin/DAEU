<?php
include('../connexion/link.php'); // Connexion à la base de données
include('../fonctions/fonction.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // A vous jouez ici !
    // En résultat, je veux la suppression d'un étudiant
    // Puis une redirection vers la page index.php !
}

?>
