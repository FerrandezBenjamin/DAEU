<?php

include('../connexion/link.php'); // Connexion à la base de données
include('../fonctions/fonction.php');

// Vérification des données envoyées en POST
if () {
    
   // A vous de jouer ! 
} else {
    // Données manquantes ou invalides
    header('Location: articles.php?error=1');
    exit();
}
?>