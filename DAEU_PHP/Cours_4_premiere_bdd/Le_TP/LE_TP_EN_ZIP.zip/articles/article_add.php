<?php
include('../connexion/link.php'); // Connexion à la base de données

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

   // A vous de jouer ! 

} else {
   echo "Une erreur est survenue.";
   die();
}
?>