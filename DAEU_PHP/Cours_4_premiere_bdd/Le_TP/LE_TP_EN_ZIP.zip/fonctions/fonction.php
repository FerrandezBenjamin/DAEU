<?php

function dd($data)
{
    var_dump($data);
    die();
}


?>