<?php
include('../connexion/link.php'); // Connexion à la base de données
include('../fonctions/fonction.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {

}

?>
