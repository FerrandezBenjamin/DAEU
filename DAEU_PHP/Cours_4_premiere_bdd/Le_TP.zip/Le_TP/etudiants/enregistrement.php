<?php
include('../connexion/link.php'); // Connexion à la base de données
include('../fonctions/fonction.php');

// Vérifier si le formulaire a été soumis
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    //
    // a faire le 26/02/2025
    //

} else {
    die("Accès non autorisé !");
}
